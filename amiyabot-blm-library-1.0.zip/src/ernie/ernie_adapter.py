
from typing import List

from core import AmiyaBotPluginInstance
from core.util.threadPool import run_in_thread_pool

from amiyabot.log import LoggerManager

from ..common.blm_types import BLMAdapter

logger = LoggerManager('BLM-ERNIE')

class ERNIEAdapter(BLMAdapter):
    def __init__(self, plugin):
        super().__init__()
        self.plugin:AmiyaBotPluginInstance = plugin
    
    def debug_log(self, msg):
        show_log = self.plugin.get_config("show_log")
        if show_log == True:
            logger.info(f'{msg}')

    def get_config(self, key):
        chatgpt_config = self.get_config("ERNIE")
        if chatgpt_config and chatgpt_config["enable"] and key in chatgpt_config:
            return chatgpt_config[key]
        return None

    async def model_list(self) -> List[dict]:  
        return [
            {"model_name":"ernie-3.5","type":"low-cost","supported_flow":["completion_flow","chat_flow"]},
            {"model_name":"ernie-4","type":"hight-cost","supported_flow":["completion_flow","chat_flow"]},
        ]