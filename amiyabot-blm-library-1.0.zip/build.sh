#!/bin/sh

python3 script_build.py "$@"